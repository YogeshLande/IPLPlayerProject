package entity;

public class IPLPlayer {
	private int id;
	private String name;
	private String team;
	private int runs;

	public IPLPlayer(int id, String name, String team, int runs) {
		this.id = id;
		this.name = name;
		this.team = team;
		this.runs = runs;

		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public int getRuns() {
		return runs;
	}

	public void setRuns(int runs) {
		this.runs = runs;
		
		
	}

	@Override
	public String toString() {
		return "IPLPlayer [id=" + id + ", name=" + name + ", team=" + team + ", runs=" + runs + "]";
	}

}
